#pragma once

#include <SDL2\SDL.h>
#include <GL\glew.h>

int initSDL(SDL_Window **win, SDL_GLContext *context);
int quitSDL(SDL_Window *win, SDL_GLContext context);