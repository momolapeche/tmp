#define SDL_MAIN_HANDLED
#include <SDL2\SDL.h>
#include <GL\glew.h>
#include "init.h"
#include "vec.h"
#include "mesh.h"
#include "shader.h"
#include "obj_loader.h"
#include "texture.h"

#include <stdio.h>

#define KEY_ESC (27)
#define KEY_PLUS (1073741911)
#define KEY_MINUS (1073741910)
#define KEY_ARROW_UP (1073741906)
#define KEY_ARROW_DOWN (1073741905)
#define KEY_ARROW_LEFT (1073741904)
#define KEY_ARROW_RIGHT (1073741903)

void update(SDL_Window *win, int *close_window, Tranformation *transformation, Mesh *mesh)
{
	SDL_Event e;

	SDL_GL_SwapWindow(win);
	while (SDL_PollEvent(&e))
	{
		if (e.type == SDL_QUIT)
			*close_window = 1;
		if (e.type == SDL_KEYDOWN)
		{
			if (e.key.keysym.sym == KEY_ESC)
				*close_window = 1;
			else if (e.key.keysym.sym == KEY_PLUS)
			{
				transformation->scale.x *= 1.3333f;
				transformation->scale.y *= 1.3333f;
				transformation->scale.z *= 1.3333f;
			}
			else if (e.key.keysym.sym == KEY_MINUS)
			{
				transformation->scale.x *= 0.75f;
				transformation->scale.y *= 0.75f;
				transformation->scale.z *= 0.75f;
			}
			else if (e.key.keysym.sym == KEY_ARROW_UP)
				transformation->translation.y += 0.1f;
			else if (e.key.keysym.sym == KEY_ARROW_DOWN)
				transformation->translation.y -= 0.1f;
			else if (e.key.keysym.sym == KEY_ARROW_LEFT)
				transformation->translation.x -= 0.1f;
			else if (e.key.keysym.sym == KEY_ARROW_RIGHT)
				transformation->translation.x += 0.1f;
			else
				printf("%i\n", e.key.keysym.sym);
		}
	}
}

void displayClear(float r, float g, float b, float a)
{
	glClearColor(r, g, b, a);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

int main(int argc, char *argv[])
{
	SDL_Window *win;
	SDL_GLContext context;
	int closeWindow = 0;

	initSDL(&win, &context);

	Mesh mesh;

	Shader shader;

	Texture texture;

	Vec3 vertices[] = {
		createVec3(-0.5f, 0.5f, 0.0f),
		createVec3(-0.5f, -0.5f, 0.0f),
		createVec3(0.5f, -0.5f, 0.0f),
		createVec3(0.5f, 0.5f, 0.0f),
	};

	unsigned int indices[] = {
		0, 1, 2,
		0, 2, 3,
	};

	Vec2 texCoords[] = {
		createVec2(0.0f, 0.0f),
		createVec2(0.0f, 1.0f),
		createVec2(1.0f, 1.0f),
		createVec2(1.0f, 0.0f),

		createVec2(0.0f, 0.0f),
		createVec2(1.0f, 1.0f),
		createVec2(1.0f, 0.0f),
	};

	OBJModel model = loadOBJ("../res/miku3", "ROOMITEMS010_ALL.obj");
	texture = createTexture(&model);
//	texture = createTexture("../res/hitomi.jpg");

	Tranformation transformation;
	initMesh(&mesh, model.positions, model.positions_size, model.indices, model.indices_size, model.texCoords, model.texCoords_size);
//	initMesh(&mesh, vertices, 4, indices, 6, texCoords, 6);

	initShader(&shader, "../res/basicShader.vs", "../res/basicShader.fs");

	transformation = createTransformation(
		createVec3(0.0f, 0.0f, 0.0f),
		createVec3(0.0f, 0.0f, 0.0f),
		createVec3(1.0f, 1.0f, 1.0f)
	);
	closeWindow = 0;
	float t = 0;
	while (!closeWindow)
	{
		transformation.rotation.y = t;
		displayClear(0.0f, 0.3f, 0.15f, 1.0f);
		//for (unsigned int i = 0; i < model.from_size - 1; ++i)
//for (unsigned int i = 0; i < 1; ++i)
		//{
			bindShader(&shader);
			updateShader(&shader, &transformation);
//			bindTexture(&texture, 0);
			bindTexture(&texture, 0);
			drawMesh(&mesh, 0, model.from[model.from_size - 1]);
		//}
		update(win, &closeWindow, &transformation, &mesh);
		t += 0.002f;
	}

	destroyTexture(&texture);
	destroyMesh(mesh);
	destroyShader(&shader);

	quitSDL(win, context);

	return 0;
}