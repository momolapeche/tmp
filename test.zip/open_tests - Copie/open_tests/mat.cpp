#include <math.h>
#include "mat.h"
#include "vec.h"

Mat4 translateMat4(Vec3 v)
{
	Mat4 m;

	m.v[0] = 1;
	m.v[1] = 0;
	m.v[2] = 0;
	m.v[3] = v.x;
	m.v[4] = 0;
	m.v[5] = 1;
	m.v[6] = 0;
	m.v[7] = v.y;
	m.v[8] = 0;
	m.v[9] = 0;
	m.v[10] = 1;
	m.v[11] = v.z;
	m.v[12] = 0;
	m.v[13] = 0;
	m.v[14] = 0;
	m.v[15] = 1;
	return m;
}

Mat4 rotateYMat4(float a)
{
	Mat4 m;

	m.v[0] = cos(a);
	m.v[1] = 0;
	m.v[2] = sin(a);
	m.v[3] = 0;
	m.v[4] = 0;
	m.v[5] = 1;
	m.v[6] = 0;
	m.v[7] = 0;
	m.v[8] = -sin(a);
	m.v[9] = 0;
	m.v[10] = cos(a);
	m.v[11] = 0;
	m.v[12] = 0;
	m.v[13] = 0;
	m.v[14] = 0;
	m.v[15] = 1;
	return m;
}

Mat4 scaleMat4(Vec3 v)
{
	Mat4 m;

	m.v[0] = v.x;
	m.v[1] = 0;
	m.v[2] = 0;
	m.v[3] = 0;
	m.v[4] = 0;
	m.v[5] = v.y;
	m.v[6] = 0;
	m.v[7] = 0;
	m.v[8] = 0;
	m.v[9] = 0;
	m.v[10] = v.z;
	m.v[11] = 0;
	m.v[12] = 0;
	m.v[13] = 0;
	m.v[14] = 0;
	m.v[15] = 1;
	return m;
}

Mat4 Mat4mulMat4(Mat4 a, Mat4 b)
{
	Mat4 m;

	m.v[0] = a.v[0] * b.v[0] + a.v[1] * b.v[4] + a.v[2] * b.v[8] + a.v[3] * b.v[12];
	m.v[1] = a.v[0] * b.v[1] + a.v[1] * b.v[5] + a.v[2] * b.v[9] + a.v[3] * b.v[13];
	m.v[2] = a.v[0] * b.v[2] + a.v[1] * b.v[6] + a.v[2] * b.v[10] + a.v[3] * b.v[14];
	m.v[3] = a.v[0] * b.v[3] + a.v[1] * b.v[7] + a.v[2] * b.v[11] + a.v[3] * b.v[15];

	m.v[4] = a.v[4] * b.v[0] + a.v[5] * b.v[4] + a.v[6] * b.v[8] + a.v[7] * b.v[12];
	m.v[5] = a.v[4] * b.v[1] + a.v[5] * b.v[5] + a.v[6] * b.v[9] + a.v[7] * b.v[13];
	m.v[6] = a.v[4] * b.v[2] + a.v[5] * b.v[6] + a.v[6] * b.v[10] + a.v[7] * b.v[14];
	m.v[7] = a.v[4] * b.v[3] + a.v[5] * b.v[7] + a.v[6] * b.v[11] + a.v[7] * b.v[15];

	m.v[8] = a.v[8] * b.v[0] + a.v[9] * b.v[4] + a.v[10] * b.v[8] + a.v[11] * b.v[12];
	m.v[9] = a.v[8] * b.v[1] + a.v[9] * b.v[5] + a.v[10] * b.v[9] + a.v[11] * b.v[13];
	m.v[10] = a.v[8] * b.v[2] + a.v[9] * b.v[6] + a.v[10] * b.v[10] + a.v[11] * b.v[14];
	m.v[11] = a.v[8] * b.v[3] + a.v[9] * b.v[7] + a.v[10] * b.v[11] + a.v[11] * b.v[15];

	m.v[12] = a.v[12] * b.v[0] + a.v[13] * b.v[4] + a.v[14] * b.v[8] + a.v[15] * b.v[12];
	m.v[13] = a.v[12] * b.v[1] + a.v[13] * b.v[5] + a.v[14] * b.v[9] + a.v[15] * b.v[13];
	m.v[14] = a.v[12] * b.v[2] + a.v[13] * b.v[6] + a.v[14] * b.v[10] + a.v[15] * b.v[14];
	m.v[15] = a.v[12] * b.v[3] + a.v[13] * b.v[7] + a.v[14] * b.v[11] + a.v[15] * b.v[15];
	return m;
}