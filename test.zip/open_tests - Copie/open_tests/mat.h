#pragma once
#include "vec.h"

typedef struct s_mat4
{
	float v[16];
} Mat4;

Mat4 translateMat4(Vec3 v);
Mat4 rotateYMat4(float a);
Mat4 scaleMat4(Vec3 v);
Mat4 Mat4mulMat4(Mat4 a, Mat4 b);
