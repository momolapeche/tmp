#include <GL\glew.h>
#include "vec.h"
#include "mesh.h"

#include <stdio.h>

void initMesh(Mesh *m, Vec3 *vertices, unsigned int vertices_size, unsigned int *indices, unsigned int indices_size,
	Vec2 *texCoords, unsigned int texCoords_size)
{
	m->drawCount = indices_size;

	glGenVertexArrays(1, &(m->vertexArrayObject));
	glBindVertexArray(m->vertexArrayObject);

	glGenBuffers(NUM_BUFFERS, m->vertexBuffers);

	glBindBuffer(GL_ARRAY_BUFFER, m->vertexBuffers[VERTEX_VB]);
	glBufferData(GL_ARRAY_BUFFER, vertices_size * sizeof(vertices[0]), vertices, GL_STATIC_DRAW);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);

	glBindBuffer(GL_ARRAY_BUFFER, m->vertexBuffers[TEXCOORD_VB]);
	glBufferData(GL_ARRAY_BUFFER, texCoords_size * sizeof(texCoords[0]), texCoords, GL_STATIC_DRAW);
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, 0);

	
	//	printf("size = %ui\n", sizeof(float));

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m->vertexBuffers[INDEX_VB]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices_size * sizeof(indices[0]), indices, GL_STATIC_DRAW);

	glBindVertexArray(0);
	printf("Mesh initialized\n");
}

void destroyMesh(Mesh mesh)
{
	glDeleteBuffers(NUM_BUFFERS, mesh.vertexBuffers);
	glDeleteVertexArrays(1, &mesh.vertexArrayObject);
}

void drawMesh(Mesh *mesh, unsigned int from, unsigned int to)
{
	glBindVertexArray(mesh->vertexArrayObject);

	glDrawElements(GL_TRIANGLES, to - from, GL_UNSIGNED_INT, (void *)(from * sizeof(unsigned int)));

	glBindVertexArray(0);
}