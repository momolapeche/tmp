#pragma once

enum e_buffers
{
	VERTEX_VB,
	TEXCOORD_VB,
	INDEX_VB,

	NUM_BUFFERS
};

typedef struct s_mesh
{
	unsigned int drawCount;
	GLuint vertexArrayObject;
	GLuint vertexBuffers[NUM_BUFFERS];
} Mesh;

void initMesh(Mesh *m, Vec3 *vertices, unsigned int vertices_size, unsigned int *indices, unsigned int indices_size,
	Vec2 *texCoords, unsigned int texCoords_size);
void destroyMesh(Mesh mesh);
void drawMesh(Mesh *mesh, unsigned int from, unsigned int to);
