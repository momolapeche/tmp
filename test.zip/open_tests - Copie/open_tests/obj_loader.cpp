#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <fstream>
#include <iostream>
#include "obj_loader.h"

static float getFloat(const std::string &line, unsigned int & index)
{
	float f;
	float div;
	int sign;

	f = 0;
	if ((sign = line[index] == '-'))
		index++;
	while (isdigit(line[index]))
	{
		f = f * 10 + line[index] - '0';
		index++;
	}
	if (line[index] == '.')
	{
		div = 10;
		index++;
		while (isdigit(line[index]))
		{
			if (div < 10000000)
			{
				f += (line[index] - '0') / div;
				div *= 10;
			}
			index++;
		}
	}
	if (line[index] == 'E')
	{
		index++;
		int expSign = line[index] == '-';
		if (line[index] == '-' || line[index] == '+')
			index++;
		int exponent = 0;
		while (isdigit(line[index]))
		{
			exponent = exponent * 10 + (line[index] - '0');
			index++;
		}
		div = 1;
		while (exponent--)
		{
			if (expSign)
				div /= 10;
			else
				div *= 10;
		}
		f *= div;
	}
	return sign ? -f : f;
}

static unsigned int getUint(const std::string & line, unsigned int & index)
{
	unsigned int u = 0;

	while (isdigit(line[index]))
	{
		u = u * 10 + (line[index] - '0');
		index++;
	}
	return u - 1;
}

static Vec3 getVertex(const std::string &line, unsigned int index)
{
	Vec3 v;

	index = 2;
	while (isspace(line[index]))
		index++;
	v.x = getFloat(line, index);
	while (isspace(line[index]))
		index++;
	v.y = getFloat(line, index);
	while (isspace(line[index]))
		index++;
	v.z = getFloat(line, index);
	return v;
}

static Vec2 getTexCoords(const std::string & line, unsigned int index)
{
	Vec2 v;

	index = 2;
	while (isspace(line[index]))
		index++;
	v.x = getFloat(line, index);
	while (isspace(line[index]))
		index++;
	v.y = -getFloat(line, index);
	return v;
}

static void getFaceVertex(OBJModel & model,  const std::string &line, unsigned int &index)
{
	unsigned int positionIndex;
	unsigned int texCoordIndex;

	model.indices[model.indices_size++] = getUint(line, index);
	if (line[index] == '/')
	{
		index++;
		texCoordIndex = getUint(line, index);
		if (line[index] == '/')
			getUint(line, index);
	}
}

static unsigned int getFace(const std::string &line, OBJModel &model)
{
	unsigned int index = 2;

	while (isspace(line[index]))
		index++;
	getFaceVertex(model, line, index);
	while (isspace(line[index]))
		index++;
	getFaceVertex(model, line, index);
	while (isspace(line[index]))
		index++;
	getFaceVertex(model, line, index);
	return 0;
}

static void addTexture(OBJModel &model, const std::string & name)
{
	unsigned int i;
	for (i = 0; i < model.materials_size; ++i)
	{
		if (name == model.materials[i].name)
			break;
	}
	model.from[model.from_size++] = model.indices_size;
	model.texture[model.texture_size++] = i;
}

static t_mtl loadMtl(std::ifstream & file, std::string & line, const std::string & dir)
{
	t_mtl mtl;
	unsigned int index;

	mtl.name = _strdup(line.substr(7, line.length() - 7).c_str());
	std::getline(file, line);
	if (!line.compare(0, 3, "Ka "))
	{
		mtl.Ka = getVertex(line, 3);
		std::getline(file, line);
	}
	if (!line.compare(0, 3, "Kd "))
	{
		mtl.Kd = getVertex(line, 3);
		std::getline(file, line);
	}
	if (!line.compare(0, 3, "Ks "))
	{
		mtl.Ks = getVertex(line, 3);
		std::getline(file, line);
	}
	if (!line.compare(0, 2, "d "))
	{
		index = 2;
		mtl.d = getFloat(line, index);
		std::getline(file, line);
	}
	if (!line.compare(0, 7, "map_Kd "))
	{
		mtl.file = _strdup((dir + '/' + line.substr(7, line.length() - 7).c_str()).c_str());
	}
	return mtl;
}

static void loadMtllib(OBJModel &model, const std::string & dir, const std::string & filename)
{
	std::ifstream file(dir + '/' + filename, std::ifstream::in);

	if (file.is_open())
	{
		std::string line;

		while (std::getline(file, line))
		{
			if (!line.compare(0, 7, "newmtl "))
			{
				model.materials[model.materials_size++] = loadMtl(file, line, dir);
			}
		}
		file.close();
	}
}

OBJModel loadOBJ(const char *dir, const char *filename)
{
	std::string fullFileName = std::string(dir) + '/' + std::string(filename);
	std::ifstream file(fullFileName, std::ifstream::in);
	std::string line;

	OBJModel model;

	model.positions = (Vec3 *)malloc(sizeof(Vec3) * OBJLOADER_POSITIONS_SIZE);
	model.positions_size = 0;
	model.indices = (unsigned int *)malloc(sizeof(unsigned int) * OBJLOADER_INDICES_SIZE);
	model.indices_size = 0;

	model.materials = (t_mtl *)malloc(sizeof(t_mtl) * OBJLOADER_MATERIALS_SIZE);
	model.materials_size = 0;

	model.texCoords = (Vec2 *)malloc(sizeof(Vec2) * OBJLOADER_TEXCOORDS_SIZE);
	model.texCoords_size = 0;

	model.from = (unsigned int *)malloc(sizeof(unsigned int) * OBJLOADER_FROM_SIZE);
	model.from_size = 0;

	model.texture = (unsigned int *)malloc(sizeof(unsigned int) * OBJLOADER_TEXTURE_SIZE);
	model.texture_size = 0;

	std::cout << "yo" << std::endl;

	if (file.is_open())
	{
		while (std::getline(file, line))
		{
			if (!line.compare(0, 7, "mtllib "))
			{
				loadMtllib(model, dir, &(line.c_str()[7]));
			}
			if (!line.compare(0, 7, "usemtl "))
			{
				addTexture(model, &(line.c_str()[7]));
			}
			if (line[0] == 'v' && line[1] == ' ')
			{
				model.positions[model.positions_size++] = getVertex(line, 2);
			}
			if (line[0] == 'v' && line[1] == 't' && line[2] == ' ')
			{
				model.texCoords[model.texCoords_size++] = getTexCoords(line, 3);
			}
			if (line[0] == 'f' && line[1] == ' ')
			{
				getFace(line, model);
			}
		}
	}

	model.from[model.from_size++] = model.indices_size;

	for (unsigned int i = 0; i < model.from_size - 1; i++)
	{
		std::cout << "from = " << model.from[i] << "texture = " << model.texture[i] << std::endl;
	}
	std::cout << "from = " << model.from[model.from_size - 1] << std::endl;
	for (unsigned int i = 0; i < model.materials_size; i++)
	{
		std::cout << "newmtl " << model.materials[i].name << std::endl;
		std::cout << "Ka " << model.materials[i].Ka.x << " " << model.materials[i].Ka.y << " " << model.materials[i].Ka.z << std::endl;
		std::cout << "Kd " << model.materials[i].Kd.x << " " << model.materials[i].Kd.y << " " << model.materials[i].Kd.z << std::endl;
		std::cout << "Ks " << model.materials[i].Ks.x << " " << model.materials[i].Ks.y << " " << model.materials[i].Ks.z << std::endl;
		std::cout << "d " << model.materials[i].d << std::endl;
		std::cout << "map_Kd " << model.materials[i].file << std::endl;
	}
	//for (unsigned int i = 0; i < model.positions_size; i++)
	//	std::cout << "v " << model.positions[i].x << " " << model.positions[i].y << " " << model.positions[i].z << std::endl;
	//for (unsigned int i = 0; i < model.indices_size; i += 3)
	//	std::cout << "f " << model.indices[i + 0] << " " << model.indices[i + 1] << " " << model.indices[i + 2] << std::endl;
	std::cout << "end" << std::endl;
	return model;
}