#pragma once
#include "vec.h"

#define OBJLOADER_POSITIONS_SIZE (1024 * 16)
#define OBJLOADER_INDICES_SIZE (1024 * 16)
#define OBJLOADER_TEXCOORDS_SIZE (1024 * 16)

#define OBJLOADER_TEXTURE_SIZE (128)
#define OBJLOADER_FROM_SIZE (128)

#define OBJLOADER_MATERIALS_SIZE (32)

typedef struct s_mtl
{
	Vec3 Ka;
	Vec3 Kd;
	Vec3 Ks;
	float d;
	char *file;
	char *name;
} t_mtl;

typedef struct s_objModel
{
	Vec3 *positions;
	unsigned int positions_size;
	unsigned int *indices;
	unsigned int indices_size;
	t_mtl *materials;
	unsigned int materials_size;
	Vec2 *texCoords;
	unsigned int texCoords_size;
	unsigned int *from;
	unsigned int from_size;
	unsigned int *texture;
	unsigned int texture_size;
} OBJModel;

OBJModel loadOBJ(const char *dir, const char *filename);