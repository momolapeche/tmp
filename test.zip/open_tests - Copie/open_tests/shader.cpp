#include <GL\glew.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "shader.h"
#include "transform.h"
#include "mat.h"

static char *loadShader(const char *fileName);
static GLuint createShader(const char *text, GLenum shaderType);
static void checkShaderError(GLuint shader, GLuint flag, int isProgram, const char *errorMessage);

void initShader(Shader *shader, const char *vertexShaderFileName, const char *fragmentShaderFileName)
{
	shader->program = glCreateProgram();

	shader->shaders[VERTEX_SHADER] = createShader(loadShader(vertexShaderFileName), GL_VERTEX_SHADER);
	shader->shaders[FRAGMENT_SHADER] = createShader(loadShader(fragmentShaderFileName), GL_FRAGMENT_SHADER);

	if (shader->shaders[VERTEX_SHADER] == 0 ||
		shader->shaders[FRAGMENT_SHADER] == 0)
	{
		printf("Error: Shader loading failed\n");
		return;
	}

	for (unsigned int i = 0; i < NUM_SHADERS; ++i)
		glAttachShader(shader->program, shader->shaders[i]);

	glBindAttribLocation(shader->program, 0, "position");
	glBindAttribLocation(shader->program, 1, "texCoord");

	glLinkProgram(shader->program);
	checkShaderError(shader->program, GL_LINK_STATUS, 1, "Error: Program linking failed");

	glValidateProgram(shader->program);
	checkShaderError(shader->program, GL_VALIDATE_STATUS, 1, "Error: Program validation failed");

	shader->uniforms[TRANSFORM_U] = glGetUniformLocation(shader->program, "transform");
//	shader->uniforms[DIFFUSE_U] = glGetUniformLocation(shader->program, "diffuse");
}

void destroyShader(Shader *shader)
{
	for (unsigned int i = 0; i < NUM_SHADERS; ++i)
	{
		glDetachShader(shader->program, shader->shaders[i]);
		glDeleteShader(shader->shaders[i]);
	}

	glDeleteProgram(shader->program);
}

void bindShader(Shader *shader)
{
	glUseProgram(shader->program);
}

void updateShader(Shader *shader, Tranformation *transformation)
{
	Mat4 m = getTranformationModel(*transformation);
	glUniformMatrix4fv(shader->uniforms[TRANSFORM_U], 1, GL_TRUE, m.v);
}

static char *loadShader(const char *fileName)
{
	char *text;
	FILE *file;
	size_t numRead;
	char buf[SHADER_BUFF_SIZE];
	char *tmp;
	size_t len;

	text = (char *)malloc(sizeof(char) * 1);
	if (text == NULL)
		return NULL;
	text[0] = '\0';

	fopen_s(&file, fileName, "r");
	len = 0;
	if (file)
	{
		while ((numRead = fread(buf, sizeof(char), SHADER_BUFF_SIZE, file)) > 0)
		{
			tmp = (char *)malloc(sizeof(char) * (len + numRead + 1));
			if (tmp == NULL)
				break;
			for (size_t i = 0; i < len; ++i)
				tmp[i] = text[i];
			for (size_t i = 0; i < numRead; ++i)
				tmp[len + i] = buf[i];
			tmp[len + numRead] = '\0';
			free(text);
			text = tmp;
			len = len + numRead;
		}
		fclose(file);
//		printf("FILE:\n%s\n", text);
		return text;
	}
	return NULL;
}

static GLuint createShader(const char *text, GLenum shaderType)
{
	if (text == NULL)
	{
		printf("Error: Empty file\n");
		return 0;
	}

	GLuint shader = glCreateShader(shaderType);

	if (shader == 0)
		printf("Error: Shader creation failed\n");

	const GLchar *shaderSourceStrings[1] = { text };
	GLint shaderSourceStringsLengths[1];

//	shaderSourceStrings[0] = text;
	shaderSourceStringsLengths[0] = strlen(text);

	printf("string = %s\nlenght = %i\n", shaderSourceStrings[0], shaderSourceStringsLengths[0]);

	glShaderSource(shader, 1, shaderSourceStrings, shaderSourceStringsLengths);
	glCompileShader(shader);

	checkShaderError(shader, GL_COMPILE_STATUS, 0, "Error: Shader compilation failed");

	return (shader);
}

static void checkShaderError(GLuint shader, GLuint flag, int isProgram, const char *errorMessage)
{
	GLint success;
	GLchar error[1024];
	unsigned int error_size;

	error_size = sizeof(GLchar) * 1024;
	memset(error, 0, error_size);

	if (isProgram)
		glGetProgramiv(shader, flag, &success);
	else
		glGetShaderiv(shader, flag, &success);

	if (success == GL_FALSE)
	{
		if (isProgram)
			glGetProgramInfoLog(shader, error_size, NULL, error);
		else
			glGetShaderInfoLog(shader, error_size, NULL, error);

		printf("%s: '%s'\n", errorMessage, error);
	}
}