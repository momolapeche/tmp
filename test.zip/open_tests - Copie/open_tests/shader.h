#pragma once
#include <GL\glew.h>
#include "transform.h"

#define SHADER_BUFF_SIZE (256)

enum
{
	VERTEX_SHADER,
	FRAGMENT_SHADER,

	NUM_SHADERS
};

enum
{
	TRANSFORM_U,
//	DIFFUSE_U,

	NUM_UNIFORMS
};

typedef struct s_shader
{
	GLuint program;

	GLint uniforms[NUM_UNIFORMS];
	GLuint shaders[NUM_SHADERS];
} Shader;

void initShader(Shader *shader, const char *fragmentShaderFileName, const char *vertexShaderFileName);
void destroyShader(Shader *shader);
void bindShader(Shader *shader);
void updateShader(Shader *shader, Tranformation *transformation);
