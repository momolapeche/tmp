#include "stb_image.h"
#include "texture.h"

Texture createTexture(OBJModel *model)
{
	int width, height, numComponents;
	stbi_uc *imageData;
	Texture t;

	glGenTextures(model->materials_size, t.texture);
	t.texture_size = model->materials_size;

	printf("texture_size = %u\n", t.texture_size);
	for (unsigned int i = 0; i < model->materials_size; i++)
	{
		imageData = stbi_load(model->materials[i].file, &width, &height, &numComponents, 4);
		if (imageData == NULL)
		{
			printf("Error: Texture loading failed for: %s\n", model->materials[i].file);
			t.texture[i] = 0;
			return t;
		}

		glBindTexture(GL_TEXTURE_2D, t.texture[i]);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, imageData);

		stbi_image_free(imageData);
	}
	return t;
}

void destroyTexture(Texture *t)
{
	glDeleteTextures(t->texture_size, t->texture);
}

void bindTexture(Texture *t, unsigned int unit)
{
	glActiveTexture(GL_TEXTURE0 + unit);
	glBindTexture(GL_TEXTURE_2D, t->texture[unit]);
}