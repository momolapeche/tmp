#pragma once
#include <GL\glew.h>
#include "obj_loader.h"

typedef struct s_texture
{
	GLuint texture[32];
	unsigned int texture_size;
} Texture;

Texture createTexture(OBJModel *model);
void destroyTexture(Texture *t);
void bindTexture(Texture *t, unsigned int unit);