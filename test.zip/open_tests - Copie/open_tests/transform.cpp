#include "transform.h"
#include "mat.h"

Tranformation createTransformation(const Vec3 translation, const Vec3 rotation, const Vec3 scale)
{
	Tranformation t;

	t.translation = translation;
	t.rotation = rotation;
	t.scale = scale;
	return t;
}

Mat4 getTranformationModel(const Tranformation t)
{
	Mat4 translation;
	Mat4 rotationY;
	Mat4 rotation;
	Mat4 scale;

	translation = translateMat4(t.translation);
	rotationY = rotateYMat4(t.rotation.y);
	rotation = rotationY;
	scale = scaleMat4(t.scale);
	return Mat4mulMat4(Mat4mulMat4(translation, rotation), scale);
}