#pragma once
#include "vec.h"
#include "mat.h"

typedef struct s_transformation
{
	Vec3 translation;
	Vec3 rotation;
	Vec3 scale;
} Tranformation;

Tranformation createTransformation(const Vec3 translation, const Vec3 rotation, const Vec3 scale);
Mat4 getTranformationModel(const Tranformation t);
