#include "vec.h"

Vec2 createVec2(float x, float y)
{
	return { x, y };
}

Vec3 createVec3(float x, float y, float z)
{
	return { x, y, z };
}

Vec4 createVec4(float x, float y, float z, float a)
{
	return { x, y, z, a };
}

Vec4 Vec3toVec4(Vec3 v, float a)
{
	return createVec4(v.x, v.y, v.z, a);
}