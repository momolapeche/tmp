#pragma once

typedef struct s_vec2
{
	float x;
	float y;
} Vec2;

typedef struct s_vec3
{
	float x;
	float y;
	float z;
} Vec3;

typedef struct s_vec4
{
	float x;
	float y;
	float z;
	float a;
} Vec4;

Vec2 createVec2(float x, float y);
Vec3 createVec3(float x, float y, float z);
Vec4 createVec4(float x, float y, float z, float a);
Vec4 Vec3toVec4(Vec3 v, float a);