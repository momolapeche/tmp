#version 330

uniform sampler2D diffuse;

varying vec2 texCoord0;

out vec4 outColor;

void main()
{
	outColor = texture2D(diffuse, texCoord0);
}